# Dataset

This folder contains the prompt text datasets.

The dataset is organized around 96 adversarial/jailbreak prompts and 96
length-matched control prompts. Each base prompt has 50 generated variants for
each perturbation family.

## Files

| File | Shape / structure | Description |
| --- | --- | --- |
| `adv_queries.py` | Python list of dicts | Adversarial prompt set. Each entry includes a `model` label and a `prompt` string. |
| `control_prompts.npy` | `(96,)` string array | Length-matched control prompts selected from Natural Instructions-style task definitions. |
| `para_synonyms_adv.npy` | `(96, 50)` string array | Synonym-substitution variants of adversarial prompts. |
| `para_synonyms_control.npy` | `(96, 50)` string array | Synonym-substitution variants of control prompts. |
| `para_swap_adv.npy` | `(96, 50)` string array | Internal-letter-swap variants of adversarial prompts. |
| `para_swap_control.npy` | `(96, 50)` string array | Internal-letter-swap variants of control prompts. |
| `para_symbol_adv.npy` | `(96, 50)` string array | Character replacement variants of adversarial prompts. This family is often displayed as `Numbers` in paper/table labels, but the filename stays `symbol`. |
| `para_symbol_control.npy` | `(96, 50)` string array | Character replacement variants of control prompts. |
| `para_leetspeak_adv.npy` | `(96, 50)` string array | Leetspeak variants of adversarial prompts. |
| `para_leetspeak_control.npy` | `(96, 50)` string array | Leetspeak variants of control prompts. |
| `control_prompt_generation.py` | Script/notebook-style code | Code used to select 96 control prompts by matching the character-length distribution of adversarial prompts. |
| `paraphrases_generation.py` | Script/notebook-style code | Code used to generate synonym, swap, symbol/number, and leetspeak prompt variants. |
| `embedding_proba_retrieval.py` | Script/notebook-style code | Code for extracting last-token embeddings and top-k next-token probabilities/IDs from language models. |
| `extracted_features_Claude_Sonnet_4.6.json` | JSON | Extracted feature metadata used by analysis notebooks/scripts. |

## Layout

The main prompt arrays follow this indexing convention:

- Axis 0 is the base prompt index, `0..95`.
- Axis 1, for paraphrase arrays, is the variant index, `0..49`.
- `para_*_adv.npy[i, j]` is perturbation variant `j` of adversarial prompt `i`.
- `para_*_control.npy[i, j]` is perturbation variant `j` of control prompt `i`.

Many downstream scripts flatten the `(96, 50)` paraphrase arrays into 4,800-row
blocks.

## Loading Examples

Load adversarial prompts:

```python
from adv_queries import prompts

adv_texts = [entry["prompt"] for entry in prompts]
```

Load control prompts or paraphrases:

```python
import numpy as np

control = np.load("control_prompts.npy", allow_pickle=True)
synonym_control = np.load("para_synonyms_control.npy", allow_pickle=True)

first_control_prompt = str(control[0])
first_variant = str(synonym_control[0, 0])
```

## Generation Notes

`control_prompt_generation.py` selects control prompts from
`pegah-a/small-natural-instructions` by matching the character lengths of the
first 96 adversarial prompts.

`paraphrases_generation.py` contains four perturbation families:

- `synonyms`: replaces eligible words using WordNet synonyms.
- `swap`: shuffles internal letters of eligible words while preserving first and last letters.
- `symbol`: replaces a fraction of non-whitespace characters with digits; this is the same family referred to as `Numbers` in some reports.
- `leetspeak`: replaces eligible characters with leetspeak-style alternatives.

The generation scripts are notebook-style and may require external packages,
model access, or local working-directory assumptions. Treat the `.npy` files as
the stable artifacts consumed by analysis scripts.

## Safety Note

`adv_queries.py` contains adversarial/jailbreak prompt text, including harmful
or policy-evading examples, for robustness evaluation. Be careful when printing,
sharing, or using these prompts outside controlled analysis workflows.

